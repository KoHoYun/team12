package simple_merge;

public class test {
  public static void main(String[] args)
  {
    new makeFrame();
    
  }
}
 