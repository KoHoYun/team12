package practice;
import java.awt.*;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.GridLayout;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.*;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.Utilities;

public class gui extends JFrame {
	
    private ImageIcon loadicon = new ImageIcon("icon\\load.png");
    private ImageIcon editicon = new ImageIcon("icon\\edit.png");
    private ImageIcon saveicon = new ImageIcon("icon\\save.png");
    private ImageIcon compareicon = new ImageIcon("icon\\compare.png");
    private ImageIcon rightic = new ImageIcon("icon\\right-arrow.png");
    private ImageIcon leftic = new ImageIcon("icon\\left-arrow.png");

	private JFileChooser filechoose = new JFileChooser();
	
	private JButton loadBtn1 = new JButton("LOAD", loadicon);
    private JButton editBtn1 = new JButton("EDIT", editicon);
    private JButton saveBtn1 = new JButton("SAVE", saveicon);
    private JButton loadBtn2 = new JButton("LOAD", loadicon);
    private JButton editBtn2 = new JButton("EDIT", editicon);
    private JButton saveBtn2 = new JButton("SAVE", saveicon);
    private JButton compareBtn = new JButton("COMPARE", compareicon);
    private JButton mergeBtn1 = new JButton("MERGE", leftic);
    private JButton mergeBtn2 = new JButton("MERGE", rightic);
    private JLabel jlb = new JLabel(" ");
    
    JPanel buttons = new JPanel();
	JPanel logo= new JPanel();
	JPanel CMbtns = new JPanel();
    JPanel blank1 = new JPanel();
    JPanel blank2 = new JPanel();
    JTextArea menupane = new JTextArea();
    JScrollPane jp = new JScrollPane(menupane);
    JTextPane leftcode = new JTextPane();
    JTextPane rightcode = new JTextPane();
    JScrollPane scroll1 = new JScrollPane(leftcode);
    JScrollPane scroll2 = new JScrollPane(rightcode);
    
    protected ImageIcon createImageIcon(String path,
            String description) {
    	java.net.URL imgURL = getClass().getResource(path);
    		if (imgURL != null) {
    			return new ImageIcon(imgURL, description);
    		} else {
    			System.err.println("Couldn't find file: " + path);
    			return null;
    		}
    }
    
	public gui() {
	
	super();
	
	Dimension dim = new Dimension(1200, 800);

	JFrame view = new JFrame("gui");
	view.setBounds(120, 120, 1200, 800);
	view.setPreferredSize(dim);
	
	JPanel main = new JPanel();
	
	JMenuBar bar = new JMenuBar();
	JMenu help = new JMenu("Help");
	JMenuItem mi = new JMenuItem("도움말");
	bar.add(help);
	help.add(mi);
	view.add(jp, "Center");
	mi.setMnemonic('F'); //단축키 F
	view.setJMenuBar(bar);
	
	main.setLayout(new BorderLayout());
	buttons.setLayout(new GridLayout(1,7));
	
	buttons.add(loadBtn1);
	buttons.add(editBtn1);
	buttons.add(saveBtn1);
	buttons.add(logo);
	buttons.add(loadBtn2);
	buttons.add(editBtn2);
	buttons.add(saveBtn2);
	
	mergeBtn1.setBorderPainted(false);
	mergeBtn2.setBorderPainted(false);
	mergeBtn1.setContentAreaFilled(false);
	mergeBtn2.setContentAreaFilled(false);

    CMbtns.setLayout(new GridLayout(5,1));
    CMbtns.add(blank1);
    CMbtns.add(compareBtn);
    CMbtns.add(blank2);
    CMbtns.add(mergeBtn1);
    CMbtns.add(mergeBtn2);


    main.add(buttons, "North"); //button이 담긴 패널을 main 패널에 
    
    JPanel Frame = new JPanel();
    Frame.setLayout(new BoxLayout(Frame, BoxLayout.X_AXIS));
    leftcode.setPreferredSize(new Dimension(500,700));
    rightcode.setPreferredSize(new Dimension(500,700));
    
    main.add(Frame, "Center");
    
    Frame.add(leftcode);
    Frame.add(CMbtns);
    Frame.add(rightcode);
    
    loadBtn1.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			
			filechoose.addChoosableFileFilter(new FileNameExtensionFilter("Text file", "txt"));
			filechoose.setAcceptAllFileFilterUsed(false);
			int returnVal = filechoose.showOpenDialog(null);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				try {
					File f = filechoose.getSelectedFile();
					new openFile(f, leftcode);
				} catch (Exception event) {
					return;
				}
			
			}
		}
    });
    
    loadBtn2.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			
			filechoose.addChoosableFileFilter(new FileNameExtensionFilter("Text file", "txt"));
			filechoose.setAcceptAllFileFilterUsed(false);
			int returnVal = filechoose.showOpenDialog(null);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				try {
					File f = filechoose.getSelectedFile();
					new openFile(f, rightcode);
				} catch (Exception event) {
					return;
				}
			
			}
		}
    });

    editBtn1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			setleft(false, true);
		}

		private void setleft(boolean b, boolean c) {
			// TODO Auto-generated method stub
			leftcode.setEditable(b);
		}
	});
    editBtn2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			setright(false, true);
		}

		private void setright(boolean b, boolean c) {
			// TODO Auto-generated method stub
			rightcode.setEditable(b);
		}
	});
    
    saveBtn1.addActionListener(new ActionListener() {

        @Override
        public void actionPerformed(ActionEvent e) {
           // 파일 save 할 수 있게
        	if(e.getSource() == saveBtn1)
            {
               JFileChooser sf =new JFileChooser();
               if(sf.showSaveDialog(saveBtn1)==sf.APPROVE_OPTION) {
            	   try
            	   {
            		   String str = leftcode.getText().trim();
            		   if(str.length()<1)
            			   return;
            		   File f = sf.getSelectedFile();
            		   FileWriter fw = new FileWriter(f);
            		   fw.write(str);
            		   fw.close();
            		   
            	   }catch(Exception ex) {
               }
        }
    
            }
        }
    });

    
    saveBtn2.addActionListener(new ActionListener() {

        @Override
        public void actionPerformed(ActionEvent e) {
           // 파일 save 할 수 있게
        	if(e.getSource() == saveBtn2)
            {
               JFileChooser sf =new JFileChooser();
               if(sf.showSaveDialog(saveBtn2)==sf.APPROVE_OPTION) {
            	   try
            	   {
            		   String str = rightcode.getText().trim();
            		   if(str.length()<1)
            			   return;
            		   File f = sf.getSelectedFile();
            		   FileWriter fw = new FileWriter(f);
            		   fw.write(str);
            		   fw.close();
            		   
            	   }catch(Exception ex) {
               }
        }
    
            }
        }
    });
    
    compareBtn.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
		}
    	
    	
    	
    });
    
    mergeBtn1.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
		}
    	
    });
    
    
    mergeBtn2.addActionListener(new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
		}
    	
    });
    
    
    view.add(main);
    view.setVisible(true);
	}
	
	
	
	
}
