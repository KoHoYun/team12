package practice;

import java.awt.Window;

import javax.swing.JFrame;

public class Open {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		gui gui = new gui();

		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}
